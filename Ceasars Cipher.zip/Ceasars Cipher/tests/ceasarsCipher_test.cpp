#include <iostream>
#include "ceasarsCipher.h"
// this tells catch to provide a main()
// only do this in one cpp file
#define CATCH_CONFIG_MAIN
#include "catch.hpp"


// #define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
// #include "doctest.h"

TEST_CASE("Testing encrypt function using default parameter")
{
  INFO("Check that encrypt has the correct output with every lowercase letter using default parameter");
  CHECK(ceasars_cipher::Encrypt('a') == 'c');
  CHECK(ceasars_cipher::Encrypt('b') == 'd');
  CHECK(ceasars_cipher::Encrypt('y') == 'a');
  CHECK(ceasars_cipher::Encrypt('z') == 'b');
}

TEST_CASE("Testing encrypt function using user chosen parameter")
{
    INFO("Check that encrypt has the correct output with every lowercase letter using user chosen parameter");
    CHECK(ceasars_cipher::Encrypt('a', 1) == 'b');
    CHECK(ceasars_cipher::Encrypt('a', 3) == 'd');
    CHECK(ceasars_cipher::Encrypt('y', 1) == 'z');
    CHECK(ceasars_cipher::Encrypt('y', 3) == 'b');
    CHECK(ceasars_cipher::Encrypt('z', 1) == 'a');
    CHECK(ceasars_cipher::Encrypt('z', 3) == 'c');
}

TEST_CASE("Testing decrypt function using default parameter")
{
    INFO("Check that decrypt has the correct output with every lowercase letter using default parameter");
    CHECK(ceasars_cipher::Decrypt('a') == 'y');
    CHECK(ceasars_cipher::Decrypt('b') == 'z');
    CHECK(ceasars_cipher::Decrypt('y') == 'w');
    CHECK(ceasars_cipher::Decrypt('z') == 'x');
}

TEST_CASE("Testing decrypt function using user chosen parameter")
{
    INFO("Check that decrypt has the correct output with every lowercase letter using user chosen parameter");
    CHECK(ceasars_cipher::Decrypt('a', 1) == 'z');
    CHECK(ceasars_cipher::Decrypt('a', 3) == 'x');
    CHECK(ceasars_cipher::Decrypt('y', 1) == 'x');
    CHECK(ceasars_cipher::Decrypt('y', 3) == 'v');
    CHECK(ceasars_cipher::Decrypt('z', 1) == 'y');
    CHECK(ceasars_cipher::Decrypt('z', 3) == 'w');
}
