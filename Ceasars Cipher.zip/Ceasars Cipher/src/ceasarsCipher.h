#ifndef CEASARS_CIPHER_H
#define CEASARS_CIPHER_H


namespace ceasars_cipher
{
    // Function Prototypes
    void GetUserInput(); //DO NOT MODIFY

    //Your Code Here0
    char Encrypt(char characterToChange, int key = 2);
    char Decrypt(char characterToChange, int key = 2);
}

#endif  // CEASARS_CIPHER_H