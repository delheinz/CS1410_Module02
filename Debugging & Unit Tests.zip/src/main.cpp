#include <iostream>
#include "debugger.h"
using namespace std;

int main()
{
    //Part 1
    cout << debugger::MultiplyTheLongWay(5, 7) << endl;

    //Part 2
    //debugger::CalculateOrderTotal();

    return 0;
}