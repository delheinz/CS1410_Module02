#include <string>
#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "debugger.h"

//Part 1
TEST_CASE("Multiply has correct output")
{
    CHECK(debugger::MultiplyTheLongWay(5, 7) == 35);
    CHECK(debugger::MultiplyTheLongWay(3, 9) == 27);

}


//Part 2
//TEST_CASE("Debugging Functions has correct output" )
//{
//    CHECK(debugger::CalculateOrderTotal() == true);
//    CHECK(debugger::CalculateOrderTotal(5) == false);
//    CHECK(debugger::CalculateOrderTotal(1) == true);
//    CHECK(debugger::CalculateOrderTotal(2) == true);
//    CHECK(debugger::CalculateOrderTotal(3) == true);
//    CHECK(debugger::CalculateOrderTotal(4) == true);
//}
//
//TEST_CASE("CalculateComboDiscount produces correct output")
//{
//    double discount = .2 * .50;
//    double correctAnswer = .50 - discount;
//    double testOutput = debugger::CalculateComboDiscount(.50);
//
//    CHECK(testOutput == correctAnswer);
//}