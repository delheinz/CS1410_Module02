#include "my_calculator.h"
#include <iostream>
/*
 *@brief add two doubles
 *@param a: left operand
 *@param b: right operand
 *@return double: result
 */

double my_calculator::add(double a, double b) {
    return a+b;
}
/*
 *@brief substract two doubles
 *@param a: left operand
 *@param b: right operand
 *@return double: result
 */
double my_calculator::substract(double a, double b) {
    return a-b;
}
/*
 *@brief multiply two doubles
 *@param a: left operand
 *@param b: right operand
 *@return double: result
 */
double my_calculator::multiply(double a, double b) {
    return a*b;
}
/*
 *@brief divide two doubles
 *@param a: left operand
 *@param b: right operand
 *@return double: result
 */
double my_calculator::divide(double a, double b) {
    return a/b;
}

/*
 *@brief multiply a double by itself as many times as the power dictates
 *@param a: left operand
 *@param b: right operand
 *@return double: result
 */
double my_calculator::exponent(double base, double power) {
    double result = 1;
    for(int i=0; i<power; i++)
        result *= base;
    return result;
}

double my_calculator::average(int count, double total) {
    return total / count;
}

int my_calculator::average(double &total) {
  std::cout<<"Enter a number, choose -1 to stop: "<<std::endl;
    double userChoice = 0;
    int count = -1;
    while(userChoice != -1) {
        total+=userChoice;
        std::cin>>userChoice;
        count++;
    }
    total = average(count, total);
    return count;
}


