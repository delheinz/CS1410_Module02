#include <iostream>
#include "my_calculator.h"
using namespace std;
using namespace my_calculator;

int main() {
    cout<<"6+3 = "<<add(6,3)<<endl;
    cout<<"6-3 = "<<substract(6,3)<<endl;
    cout<<"6*3 = "<<multiply(6,3)<<endl;
    cout<<"6/3 = "<<divide(6,3)<<endl;

    cout<<"2^5 = "<<exponent(2,5)<<endl;

    cout<<"Average Functions: "<<endl;
    int result = average(3,6);
    cout<<"Getting average of 6 and 3"<<result<<endl;
    double total = 0;
    int count  = average(total);
    cout<<"Getting average from user: "<<total<<endl;
    cout<<"The user input: "<< count<<" items"<<endl;
    return 0;


}
