#include <iostream>
#include <iomanip>
#include "debugger.h"


//Part 1
int debugger::MultiplyTheLongWay(int leftOperand, int rightOperand)
{

    int result = 0;
    for(int i = 0; i < rightOperand; i++);
        result += leftOperand;

    return result;
}

//Part 2
//double debugger::CalculateComboDiscount(double amount)
//{
//    double discount = amount * .2;
//    double newPrice = amount + discount;
//    return newPrice;
//}
//
//bool debugger::CalculateOrderTotal(int userChoice)
//{
//    double hamburger = 3.99;
//    double fries = .99;
//    double drink = .99;
//    std::cout << "Would you like: \n1. Hamburger\n2. Fries\n3. Drink\n4. All three (20% discount!)" << std::endl;
//    //Keep the following line commented out for testing, can uncomment for working with in main.cpp
//    //std::cin >> userChoice;
//    std::cout << "You chose option " << userChoice << std::endl;
//
//    std::cout << "Your total is: ";
//    switch(userChoice)
//    {
//        case 1:
//            std::cout << '$' << std::fixed << std::setprecision(2) << hamburger << std::endl;
//            break;
//        case 2:
//            std::cout << '$' << std::fixed << std::setprecision(2) << fries << std::endl;
//            break;
//        case 3:
//            std::cout << '$' << std::fixed << std::setprecision(2) << drink << std::endl;
//            break;
//        case 4:
//            std::cout << '$' << std::fixed << std::setprecision(2) << CalculateComboDiscount(hamburger + fries + drink) << std::endl;
//
//        default:
//            return false;
//    }
//
//    return true;
//}


