#include <iostream>
#include <string>
#include "ceasarsCipher.h"

/*
 * @brief Uses console to ask user to enter a word.
 * Asks user to choose either encrypt or decrypt.
 * Calls whichever function user chooses.
 * Prints transformed word.
 */
void ceasars_cipher::GetUserInput() {

    int userChoice = 0;
    std::string word;
    std::cout << "Please input a word: " << std::endl;
    std::cin >> word;
    std::cout << "Would you like to encrypt or decrypt" << std::endl;
    std::cout <<"1. Encrypt \n2. Decrypt" << std::endl;
    std::cin >> userChoice;

    if(userChoice < 1 || userChoice > 2)
    {
        std::cerr << "Incorrect input" << std::endl;
    }
    else if(userChoice == 1)
    {
        for(int i = 0; i < word.length(); i++)
            std::cout << Encrypt(word[i]);
    }
    else
    {
        for(int i = 0; i < word.length(); i++)
            std::cout << Decrypt(word[i]);
    }
}

char ceasars_cipher::Encrypt(char characterToChange, int key) {
    //encrypt for lowercase leter
    if (characterToChange>='a' && characterToChange<='z') {
        characterToChange += key;
        if(characterToChange>'z') {
            characterToChange = characterToChange -'z'+'a'-1;

        }
    }
    return characterToChange;
}
char ceasars_cipher::Decrypt(char characterToChange, int key) {
    if(characterToChange>='a' && characterToChange<='z') {
        characterToChange -=key;
        if(characterToChange<'a') {
            characterToChange = characterToChange +'z' -'a'+1;
        }
    }
    return characterToChange;
}




