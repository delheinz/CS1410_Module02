#ifndef DEBUGGER_H
#define DEBUGGER_H

namespace debugger
{
    //Part 1
    int MultiplyTheLongWay(int leftOperand, int rightOperand)

    //Part 2
//    double CalculateComboDiscount(double amount);
//    bool CalculateOrderTotal(int userChoice = 4);
}

#endif
