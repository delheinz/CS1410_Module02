//
// Created by jyucrazevallos on 5/11/2024.
//
#ifndef MY_CALCULATOR_H
#define MY_CALCULATOR_H

namespace my_calculator {
   double add(double a, double b);
   double substract(double a, double b);
   double multiply(double a,double b);
   double divide(double a, double b);

   double exponent(double base, double power);
   double average(int count, double total);
   int average(double& total);
}

#endif //MY_CALCULATOR_H
